# GiftNaija v1 — Production Launch Checklist

## Accounts owned by GiftNaija
- [ ] Domain registrar/DNS
- [ ] Cloud hosting
- [ ] PostgreSQL
- [ ] Redis
- [ ] Private object storage
- [ ] Email provider
- [ ] SMS/WhatsApp provider if used
- [ ] Paystack business account
- [ ] Monitoring/error tracking
- [ ] Source repository

## Application
- [ ] Set all production secrets in the host secret manager
- [ ] Never commit `.env` or live API keys
- [ ] Run Prisma migrations against a backup-protected production database
- [ ] Create a dedicated admin account and change bootstrap credentials
- [ ] Enable HTTPS and HSTS
- [ ] Configure WAF/rate limiting
- [ ] Configure private evidence storage
- [ ] Configure email delivery for password reset/notifications
- [ ] Configure webhook URL: `/api/webhooks/payout`
- [ ] Confirm webhook signature verification
- [ ] Confirm webhook events are idempotent
- [ ] Confirm payout references are unique
- [ ] Confirm failed/reversed payouts do not become `Paid`

## Paystack
- [ ] Complete business activation/provider onboarding
- [ ] Test bank account resolution in test mode
- [ ] Test recipient creation
- [ ] Test payout success/failure/reversal events
- [ ] Confirm transfer balance and limits
- [ ] Switch to live credentials only after UAT and approvals

## Security
- [ ] Independent security review/penetration test
- [ ] Dependency audit
- [ ] Backup restoration test
- [ ] Admin MFA/2FA policy enabled before live operations
- [ ] Least-privilege production access
- [ ] Log/alert on suspicious admin and payout activity
- [ ] Confirm no sensitive card data appears in application logs

## Legal/compliance
- [ ] Terms approved
- [ ] Privacy policy approved
- [ ] Cookie policy approved if applicable
- [ ] Gift-card trading/prohibited-use policy approved
- [ ] Consumer/refund/dispute policy approved
- [ ] Applicable Nigerian privacy, AML/KYC, tax and payment requirements reviewed

## Go-live gate
Real-money payouts should remain disabled until all required technical, provider, security and legal/compliance checks are signed off.
