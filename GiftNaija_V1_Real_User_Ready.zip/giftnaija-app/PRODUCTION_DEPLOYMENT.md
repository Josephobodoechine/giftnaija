# GiftNaija v1 Production Deployment Runbook

## 1. Required accounts

Create these accounts in GiftNaija's business ownership, not a developer's personal ownership:

- Cloud hosting
- Managed PostgreSQL
- Redis
- Object storage
- Domain/DNS/CDN/WAF
- Git repository
- Paystack business account
- Email provider
- SMS/WhatsApp provider, if enabled
- Monitoring/error tracking

## 2. Secrets

Generate a long random `AUTH_PEPPER`. Never use the example value. Store all production secrets in the hosting provider's secret manager.

Required variables:

- `DATABASE_URL`
- `AUTH_PEPPER`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `APP_URL`
- `PAYSTACK_SECRET_KEY`
- `PAYSTACK_WEBHOOK_SECRET` (if separately configured)
- `REDIS_URL`
- S3-compatible storage variables

## 3. Database

Run:

```bash
npm ci
npx prisma generate
npx prisma db push
npm run db:seed
```

For a regulated production deployment, replace `db push` with reviewed Prisma migrations before launch.

## 4. Paystack

Use test credentials first. Configure the webhook endpoint:

`https://YOUR-DOMAIN/api/webhooks/payout`

The webhook handler verifies the Paystack HMAC signature, stores the event idempotently, and updates payout state only for known payout references.

Before enabling live payouts, complete provider onboarding, funding/settlement setup, business verification and UAT.

## 5. Object storage

Set the S3-compatible variables. Production uploads should use private buckets. Public object URLs should not be enabled.

## 6. Security checklist

- HTTPS only
- Admin 2FA enabled before production
- Production secrets outside source control
- Database backups enabled
- Restore test completed
- Redis protected from public internet
- Private object storage
- WAF/rate limiting enabled
- Monitoring and alerts configured
- Dependency/security scanning enabled
- UAT completed
- Independent security review completed before real-money launch

## 7. Launch sequence

1. Deploy staging.
2. Seed test rates and test admin.
3. Run customer registration and transaction UAT.
4. Run payout tests with provider test mode.
5. Test webhook retries and duplicate webhook delivery.
6. Test failed/reversed payouts.
7. Test file uploads with invalid MIME/magic bytes.
8. Verify audit logs.
9. Verify backups and restore.
10. Switch provider credentials to live only after business/compliance approval.
11. Configure live webhook.
12. Run a controlled low-value production payout.
13. Monitor logs, alerts and reconciliation.

## 8. Important limitation

The source package is not itself a production deployment. Cloud/provider accounts, legal approvals, live API credentials, business verification, domain configuration and independent security testing require actions by the GiftNaija business.
