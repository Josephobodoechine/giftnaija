# GiftNaija production readiness

## Completed in v1 source
- PostgreSQL/Prisma relational model
- Secure session cookies
- Scrypt password hashing with application pepper
- Encrypted payout account numbers
- Server-side rate calculations
- Transaction status state machine
- Transaction history and audit logs
- Risk-case-ready schema
- Financial ledger-ready schema
- Payout attempts and idempotency records
- Paystack NGN account-resolution/recipient/transfer adapter
- Paystack webhook signature verification and event de-duplication
- Admin/customer/support roles
- Secure file upload validation
- Security response headers
- Docker and local PostgreSQL/Redis setup

## Required before live money
1. Complete legal/regulatory review and provider onboarding.
2. Configure production secrets in a secrets manager.
3. Use managed PostgreSQL with point-in-time recovery/backups.
4. Move uploads to private object storage and add malware scanning.
5. Configure Cloudflare/WAF/rate limiting.
6. Configure email/SMS/WhatsApp providers if required.
7. Enable production monitoring, alerts and centralized logs.
8. Run dependency, SAST/DAST and independent penetration testing.
9. Test backup restoration and payout reconciliation.
10. Configure Paystack live webhook endpoint and test failure/retry cases.
11. Review gift-card verification, fraud and prohibited-use procedures with counsel/compliance.
12. Perform UAT against the signed SOW.
