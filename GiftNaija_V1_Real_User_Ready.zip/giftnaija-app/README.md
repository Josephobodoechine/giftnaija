# GiftNaija v1

Production-oriented full-stack foundation for a Nigerian gift-card trading platform.

## Stack
- Next.js 14 + React + TypeScript
- PostgreSQL + Prisma
- Redis-ready architecture
- Secure HTTP-only session cookies
- Node crypto scrypt password hashing + encrypted payout account numbers
- Paystack bank verification and NGN transfer adapter
- Server-side rate calculation
- Admin/customer/support roles
- Transaction state machine, audit logs, ledger-ready schema, webhook idempotency

## Local development
1. Copy `.env.example` to `.env` and replace all secrets.
2. Start PostgreSQL/Redis: `docker compose up -d`
3. Install: `npm install`
4. Generate/apply schema: `npx prisma db push`
5. Seed: `npm run db:seed`
6. Run: `npm run dev`
7. Visit `http://localhost:3000`

The seed creates an admin account using `ADMIN_EMAIL` and `ADMIN_PASSWORD`.

## Paystack
The production payout adapter uses Paystack's Nigerian account-resolution, transfer-recipient and transfer APIs. Set `PAYSTACK_SECRET_KEY` and configure the webhook endpoint as:
`POST /api/webhooks/payout`

Use test credentials until the business has completed provider onboarding and compliance requirements. Paystack documents Nigerian account resolution and NGN transfers in its developer documentation.

## Production checklist
- Use managed PostgreSQL with automated backups.
- Use private object storage rather than local uploads.
- Set a strong random `AUTH_PEPPER`.
- Set `Secure` cookies behind HTTPS.
- Configure Paystack live credentials only after approval.
- Configure webhook signature verification.
- Add WAF/rate limiting at the edge.
- Add malware scanning for uploaded evidence.
- Add centralized logs/monitoring and alerting.
- Run migration backups and restoration tests.
- Complete legal/compliance review and security testing before live transactions.

## Important
This repository is a software implementation foundation. Real-money launch still depends on business/provider onboarding, legal and regulatory review, security testing, and production infrastructure configuration. No live provider credentials are included.

## Launching for real users
This repository is deployable, but production activation requires accounts owned by GiftNaija: cloud hosting, PostgreSQL, object storage, email/SMS provider, and a verified live payout provider account. Do not put live secrets in source control.

### Required production sequence
1. Provision managed PostgreSQL and Redis.
2. Configure a private S3-compatible bucket for evidence files.
3. Set a strong AUTH_PEPPER and all provider secrets through the host's secret manager.
4. Run `npx prisma migrate deploy` and seed only controlled reference data.
5. Configure the public HTTPS `APP_URL`.
6. Configure the payout provider webhook at `/api/webhooks/payout` and verify its HMAC signature.
7. Use provider test mode for full UAT before switching to live credentials.
8. Configure transactional email and replace the development password-reset console output with the chosen provider.
9. Run security testing, backup restoration tests and UAT.
10. Obtain legal/compliance approval before enabling real-money payouts.

### Operational rule
The application must not advertise a payout as completed merely because a transfer request was accepted. Final payout status is updated from the provider's verified final event. Paystack documents `transfer.success`, `transfer.failed`, and `transfer.reversed` webhook events and recommends webhook verification for final transfer status.
