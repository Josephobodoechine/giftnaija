# GiftNaija Security Runbook

## Before launch

- Rotate all development secrets.
- Disable demo/default administrator credentials.
- Enforce strong admin password and MFA.
- Confirm least-privilege RBAC.
- Verify session expiry and logout invalidation.
- Confirm webhook signature verification.
- Confirm payout references are unique and idempotent.
- Confirm transaction status transitions are server-side.
- Confirm historical rate IDs are retained.
- Confirm uploaded files are private and content-validated.
- Confirm sensitive account numbers are encrypted.
- Confirm logs do not contain raw account numbers, secrets or gift-card credentials.
- Enable monitoring and alerting.
- Perform vulnerability scanning and penetration testing.

## Incident response

1. Restrict affected account/provider/API if necessary.
2. Preserve relevant audit and webhook evidence.
3. Rotate compromised credentials.
4. Assess affected records.
5. Notify the appropriate internal owner and professional advisers.
6. Restore from known-good infrastructure if required.
7. Reconcile financial records.
8. Document remediation.
