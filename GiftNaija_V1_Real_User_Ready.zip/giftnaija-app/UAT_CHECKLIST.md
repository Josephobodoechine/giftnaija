# GiftNaija v1 UAT Checklist

## Customer
- [ ] Register
- [ ] Login/logout
- [ ] Password rejection/validation
- [ ] View rates
- [ ] Calculate estimate
- [ ] Submit transaction
- [ ] Upload valid evidence
- [ ] Reject oversized file
- [ ] Reject spoofed file type
- [ ] View transaction history
- [ ] View status history
- [ ] Add payout account
- [ ] Resolve/verify bank account
- [ ] Create support ticket
- [ ] Receive notification

## Admin
- [ ] Admin login
- [ ] View dashboard
- [ ] Search users
- [ ] Suspend/restore user
- [ ] Create/disable rate
- [ ] Review transaction
- [ ] Request verification
- [ ] Approve transaction
- [ ] Reject transaction
- [ ] Create payout
- [ ] View payout status
- [ ] View audit log

## Payments
- [ ] Provider test transfer
- [ ] Successful webhook
- [ ] Failed webhook
- [ ] Reversed webhook
- [ ] Duplicate webhook
- [ ] Duplicate payout attempt
- [ ] Provider timeout
- [ ] Reconciliation

## Security
- [ ] RBAC
- [ ] Rate limiting
- [ ] Session expiry
- [ ] CSRF review
- [ ] XSS review
- [ ] SQL injection review
- [ ] File upload security
- [ ] Secrets review
- [ ] Backup restore
