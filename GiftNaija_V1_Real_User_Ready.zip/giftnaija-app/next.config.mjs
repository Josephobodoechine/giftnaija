/** @type {import('next').NextConfig} */
const nextConfig={experimental:{serverActions:{bodySizeLimit:'12mb'}},poweredByHeader:false};export default nextConfig;
