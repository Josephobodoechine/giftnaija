import { PrismaClient, RateStatus } from '@prisma/client';
import crypto from 'crypto';
const prisma = new PrismaClient();
function hash(v:string){return crypto.scryptSync(v, process.env.AUTH_PEPPER || 'dev-pepper', 32).toString('hex')}
async function main(){
 const adminEmail=process.env.ADMIN_EMAIL || 'admin@giftnaija.local';
 const adminPassword=process.env.ADMIN_PASSWORD || 'ChangeMe-Admin-123!';
 await prisma.user.upsert({where:{email:adminEmail},update:{},create:{fullName:'GiftNaija Administrator',email:adminEmail,phone:'0000000000',passwordHash:hash(adminPassword),role:'admin',emailVerified:true,phoneVerified:true}});
 const brands=[['Apple','United States','USD',1450],['Google Play','United States','USD',1400],['Amazon','United States','USD',1350],['Steam','United States','USD',1300],['PlayStation','United States','USD',1325],['Xbox','United States','USD',1300],['Razer Gold','United States','USD',1280],['Sephora','United States','USD',1250],['Walmart','United States','USD',1275],['eBay','United States','USD',1275]] as const;
 for(const [name,country,currency,rate] of brands){const brand=await prisma.giftCardBrand.upsert({where:{name},update:{status:RateStatus.active},create:{name}});const type=await prisma.giftCardType.upsert({where:{brandId_country_currency_cardType:{brandId:brand.id,country,currency,cardType:'Digital'}},update:{status:RateStatus.active},create:{brandId:brand.id,country,currency,cardType:'Digital'}});const existing=await prisma.rate.findFirst({where:{giftCardTypeId:type.id,status:RateStatus.active}});if(!existing)await prisma.rate.create({data:{giftCardTypeId:type.id,rate,minimumValue:10,maximumValue:5000,activeFrom:new Date(),status:RateStatus.active}})}
}
main().finally(()=>prisma.$disconnect());
