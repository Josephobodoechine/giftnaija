import { prisma, json, tokenHash } from '@/lib';
import crypto from 'crypto';
import { z } from 'zod';
const schema=z.object({email:z.string().email()});
export async function POST(req:Request){
  try{
    const {email}=schema.parse(await req.json());
    const user=await prisma.user.findUnique({where:{email:email.toLowerCase()}});
    // Do not reveal whether an account exists.
    if(!user) return json({ok:true,message:'If an account exists, reset instructions will be sent.'});
    const raw=crypto.randomBytes(32).toString('base64url');
    await prisma.passwordResetToken.deleteMany({where:{userId:user.id,usedAt:null}});
    await prisma.passwordResetToken.create({data:{tokenHash:tokenHash(raw),userId:user.id,expiresAt:new Date(Date.now()+30*60*1000)}});
    // Email delivery is intentionally provider-neutral. In production, enqueue this URL with the configured email provider.
    const resetUrl=`${process.env.APP_URL||'http://localhost:3000'}/?reset=${encodeURIComponent(raw)}`;
    if(process.env.NODE_ENV!=='production') console.log(`[GiftNaija] Password reset URL: ${resetUrl}`);
    return json({ok:true,message:'If an account exists, reset instructions will be sent.',...(process.env.NODE_ENV!=='production'?{developmentResetUrl:resetUrl}: {})});
  }catch{return json({error:'Invalid request'},400)}
}
