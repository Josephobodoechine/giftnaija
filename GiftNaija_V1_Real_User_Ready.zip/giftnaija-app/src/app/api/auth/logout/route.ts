import { prisma,tokenHash,json } from '@/lib';
export async function POST(req:Request){const token=req.headers.get('cookie')?.match(/(?:^|; )gn_session=([^;]+)/)?.[1];if(token)await prisma.session.deleteMany({where:{tokenHash:tokenHash(decodeURIComponent(token))}});const res=json({ok:true});res.headers.append('Set-Cookie','gn_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0');return res}
