import {currentUser,json,safeUser} from '@/lib';
export async function GET(){const u=await currentUser();return u?json({user:safeUser(u)}):json({user:null})}
