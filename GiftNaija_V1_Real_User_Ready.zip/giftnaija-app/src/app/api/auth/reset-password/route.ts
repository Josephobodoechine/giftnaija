import { prisma, json, tokenHash, passwordHash } from '@/lib';
import { z } from 'zod';
const schema=z.object({token:z.string().min(20),password:z.string().min(10).max(128)});
export async function POST(req:Request){
  try{
    const {token,password}=schema.parse(await req.json());
    const row=await prisma.passwordResetToken.findUnique({where:{tokenHash:tokenHash(token)}});
    if(!row||row.usedAt||row.expiresAt<new Date()) return json({error:'Invalid or expired reset token'},400);
    await prisma.$transaction([
      prisma.user.update({where:{id:row.userId},data:{passwordHash:passwordHash(password)}}),
      prisma.passwordResetToken.update({where:{id:row.id},data:{usedAt:new Date()}}),
      prisma.session.deleteMany({where:{userId:row.userId}}),
      prisma.auditLog.create({data:{actorId:row.userId,action:'PASSWORD_RESET',entityType:'user',entityId:row.userId}})
    ]);
    return json({ok:true});
  }catch{return json({error:'Invalid request'},400)}
}
