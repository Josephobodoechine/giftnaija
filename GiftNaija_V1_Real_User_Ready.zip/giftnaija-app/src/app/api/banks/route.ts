import {json,currentUser} from '@/lib';
import {listBanks} from '@/server/paystack';
export async function GET(){const u=await currentUser();if(!u)return json({error:'Unauthorized'},401);try{return json(await listBanks())}catch(e:any){return json({error:e.message},503)}}
