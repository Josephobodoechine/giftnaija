import { prisma } from '@/lib';
export async function GET(){
  try{await prisma.$queryRaw`SELECT 1`;return Response.json({ok:true,service:'giftnaija',database:'ok',time:new Date().toISOString()});}
  catch{return Response.json({ok:false,service:'giftnaija',database:'error'},{status:503});}
}
