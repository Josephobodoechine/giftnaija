import { prisma,currentUser,json } from '@/lib';
export async function PATCH(_req:Request,{params}:{params:{id:string}}){const u=await currentUser();if(!u)return json({error:'Unauthorized'},401);const n=await prisma.notification.updateMany({where:{id:params.id,userId:u.id},data:{readAt:new Date()}});return json({ok:n.count===1})}
