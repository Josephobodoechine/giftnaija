import { prisma,currentUser,json } from '@/lib';
export async function GET(){const u=await currentUser();if(!u)return json({error:'Unauthorized'},401);return json(await prisma.notification.findMany({where:{userId:u.id},orderBy:{createdAt:'desc'},take:100}))}
