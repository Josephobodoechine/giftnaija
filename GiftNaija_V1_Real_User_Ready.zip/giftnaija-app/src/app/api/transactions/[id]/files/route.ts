import { prisma,currentUser,json } from '@/lib';
import { storeEvidence } from '@/server/storage';

export async function POST(req:Request,{params}:{params:{id:string}}){
  const u=await currentUser();
  if(!u) return json({error:'Unauthorized'},401);
  const t=await prisma.transaction.findUnique({where:{id:params.id}});
  if(!t || (t.userId!==u.id && u.role!=='admin')) return json({error:'Not found'},404);
  const fd=await req.formData();
  const file=fd.get('file');
  if(!(file instanceof File)) return json({error:'File required'},400);
  try{
    const saved=await storeEvidence(file,t.id);
    const row=await prisma.transactionFile.create({data:{transactionId:t.id,...saved}});
    await prisma.auditLog.create({data:{actorId:u.id,action:'UPLOAD_TRANSACTION_FILE',entityType:'transaction',entityId:t.id,metadata:{fileId:row.id,sha256:saved.sha256}}});
    return json({id:row.id,name:row.originalName,size:row.size},201);
  }catch(e:any){ return json({error:e.message||'Upload failed'},400); }
}
