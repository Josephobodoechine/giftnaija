import { prisma, currentUser, json, decimalNumber } from '@/lib';

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const u = await currentUser();
  if (!u) return json({ error: 'Unauthorized' }, 401);

  const t = await prisma.transaction.findUnique({
    where: { id: params.id },
    include: {
      giftCardType: { include: { brand: true } },
      statusHistory: { orderBy: { createdAt: 'asc' } },
      payout: true,
      files: { select: { id: true, originalName: true, mimeType: true, size: true, createdAt: true } },
    },
  });

  if (!t || (t.userId !== u.id && u.role !== 'admin')) return json({ error: 'Not found' }, 404);
  return json({
    ...t,
    submittedValue: decimalNumber(t.submittedValue),
    estimatedPayout: decimalNumber(t.estimatedPayout),
    verifiedValue: decimalNumber(t.verifiedValue),
    finalPayout: decimalNumber(t.finalPayout),
  });
}
