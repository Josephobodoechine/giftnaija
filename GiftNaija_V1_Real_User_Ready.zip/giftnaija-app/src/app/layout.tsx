import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata={title:'GiftNaija — Sell Gift Cards for NGN',description:'Secure Nigerian gift-card trading platform.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
