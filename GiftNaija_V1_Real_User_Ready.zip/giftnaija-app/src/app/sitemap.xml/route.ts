export async function GET(){
  const base=process.env.APP_URL||'http://localhost:3000';
  const urls=['/','/legal/terms','/legal/privacy'];
  const xml=`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.map(u=>`<url><loc>${base}${u}</loc></url>`).join('')}</urlset>`;
  return new Response(xml,{headers:{'content-type':'application/xml'}});
}
