import { PrismaClient, TransactionStatus, UserRole } from '@prisma/client';
import crypto from 'crypto';
import { cookies } from 'next/headers';

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };
export const prisma = globalForPrisma.prisma ?? new PrismaClient();
if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;

export function json(data: unknown, status=200){
  return new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json'}});
}
export function id(prefix:string){return `${prefix}_${crypto.randomBytes(8).toString('hex')}`}
export function sessionToken(){return crypto.randomBytes(32).toString('base64url')}
export function tokenHash(token:string){return crypto.createHash('sha256').update(`${token}:${process.env.AUTH_PEPPER||'change-me'}`).digest('hex')}
export function passwordHash(password:string){
  const salt=crypto.randomBytes(16);
  const derived=crypto.scryptSync(password, Buffer.concat([salt,Buffer.from(process.env.AUTH_PEPPER||'change-me')]),32);
  return `${salt.toString('hex')}:${derived.toString('hex')}`;
}
export function passwordVerify(password:string, stored:string){
  const [saltHex,hashHex]=stored.split(':'); if(!saltHex||!hashHex)return false;
  const derived=crypto.scryptSync(password,Buffer.concat([Buffer.from(saltHex,'hex'),Buffer.from(process.env.AUTH_PEPPER||'change-me')]),32);
  return crypto.timingSafeEqual(derived,Buffer.from(hashHex,'hex'));
}
export function transactionRef(){return `GN${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(3).toString('hex').toUpperCase()}`}
export function payoutRef(){return `GNP-${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`}
export function assertStatusTransition(from:TransactionStatus,to:TransactionStatus){
 const allowed:Record<TransactionStatus,TransactionStatus[]>={
  Draft:[TransactionStatus.Submitted,TransactionStatus.Cancelled],
  Submitted:[TransactionStatus.UnderReview,TransactionStatus.VerificationRequired,TransactionStatus.Rejected,TransactionStatus.Cancelled],
  UnderReview:[TransactionStatus.VerificationRequired,TransactionStatus.Approved,TransactionStatus.Rejected,TransactionStatus.Disputed],
  VerificationRequired:[TransactionStatus.UnderReview,TransactionStatus.Rejected,TransactionStatus.Cancelled],
  Approved:[TransactionStatus.PaymentProcessing,TransactionStatus.Disputed],
  PaymentProcessing:[TransactionStatus.Paid,TransactionStatus.Disputed],
  Paid:[],Rejected:[],Cancelled:[],Disputed:[TransactionStatus.UnderReview,TransactionStatus.Rejected]
 };
 return allowed[from]?.includes(to) ?? false;
}
export async function currentUser(){
 const token=(await cookies()).get('gn_session')?.value; if(!token)return null;
 const s=await prisma.session.findUnique({where:{tokenHash:tokenHash(token)},include:{user:true}});
 if(!s||s.expiresAt<new Date()||s.user.status!=='active')return null;
 return s.user;
}
export async function requireUser(){const u=await currentUser();if(!u)throw new Error('UNAUTHORIZED');return u}
export function safeUser(u:any){return {id:u.id,fullName:u.fullName,email:u.email,phone:u.phone,role:u.role,status:u.status,emailVerified:u.emailVerified,phoneVerified:u.phoneVerified}}
export function isAdmin(role:UserRole){return role==='admin'}
export function decimalNumber(v:any){return Number(v?.toString?.() ?? v ?? 0)}
