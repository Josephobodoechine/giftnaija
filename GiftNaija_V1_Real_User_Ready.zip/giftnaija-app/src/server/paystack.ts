import crypto from 'crypto';
const base='https://api.paystack.co';
function key(){const k=process.env.PAYSTACK_SECRET_KEY;if(!k)throw new Error('PAYSTACK_SECRET_KEY is not configured');return k}
async function request(path:string, init:RequestInit={}){const r=await fetch(`${base}${path}`,{...init,headers:{Authorization:`Bearer ${key()}`,'Content-Type':'application/json',...(init.headers||{})},cache:'no-store'});const d=await r.json();if(!r.ok||d.status===false)throw new Error(d.message||`Paystack request failed (${r.status})`);return d.data}
export async function listBanks(){return request('/bank?country=nigeria&perPage=100')}
export async function resolveAccount(account_number:string,bank_code:string){return request(`/bank/resolve?account_number=${encodeURIComponent(account_number)}&bank_code=${encodeURIComponent(bank_code)}`)}
export async function createRecipient(name:string,account_number:string,bank_code:string,email?:string){return request('/transferrecipient',{method:'POST',body:JSON.stringify({type:'nuban',name,account_number,bank_code,currency:'NGN',email})})}
export async function initiateTransfer(amountNgn:number,recipient:string,reference:string,reason:string){return request('/transfer',{method:'POST',body:JSON.stringify({source:'balance',amount:Math.round(amountNgn*100),recipient,reference,currency:'NGN',reason})})}
export function verifyWebhook(raw:string,signature:string){const secret=process.env.PAYSTACK_WEBHOOK_SECRET||process.env.PAYSTACK_SECRET_KEY||'';if(!secret)return false;const expected=crypto.createHmac('sha512',secret).update(raw).digest('hex');return signature.length===expected.length&&crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))}
