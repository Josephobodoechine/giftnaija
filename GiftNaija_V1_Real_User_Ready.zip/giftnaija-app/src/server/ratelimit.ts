import Redis from 'ioredis';
let client:Redis | null = null;
function redis(){ if(!process.env.REDIS_URL) return null; if(!client) client=new Redis(process.env.REDIS_URL,{maxRetriesPerRequest:1}); return client; }
export async function rateLimit(key:string,limit:number,windowSeconds:number){
  const r=redis();
  if(!r) return {allowed:true,remaining:limit};
  const bucket=`rl:${key}`;
  const n=await r.incr(bucket);
  if(n===1) await r.expire(bucket,windowSeconds);
  return {allowed:n<=limit,remaining:Math.max(0,limit-n)};
}
