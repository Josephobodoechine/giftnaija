import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

const allowed = new Set(['image/jpeg','image/png','application/pdf']);
const maxBytes = Number(process.env.MAX_UPLOAD_BYTES || 10 * 1024 * 1024);

function s3(){
  if(!process.env.S3_BUCKET) return null;
  return new S3Client({
    region: process.env.S3_REGION || 'auto',
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
    credentials: process.env.S3_ACCESS_KEY_ID ? {
      accessKeyId: process.env.S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || ''
    } : undefined
  });
}

function safeName(name:string){ return name.replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,180); }

function magicMatches(type:string, b:Buffer){
  if(type==='image/jpeg') return b.length>3 && b[0]===0xff && b[1]===0xd8 && b[2]===0xff;
  if(type==='image/png') return b.length>8 && b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if(type==='application/pdf') return b.subarray(0,5).toString('ascii')==='%PDF-';
  return false;
}

export async function storeEvidence(file:File, transactionId:string){
  if(!allowed.has(file.type)) throw new Error('Unsupported file type');
  if(file.size>maxBytes) throw new Error('File too large');
  const bytes=Buffer.from(await file.arrayBuffer());
  if(!magicMatches(file.type,bytes)) throw new Error('File content does not match its declared type');
  const sha256=crypto.createHash('sha256').update(bytes).digest('hex');
  const key=`transactions/${transactionId}/${Date.now()}-${crypto.randomBytes(10).toString('hex')}-${safeName(file.name)}`;
  const client=s3();
  if(client){
    await client.send(new PutObjectCommand({Bucket:process.env.S3_BUCKET!,Key:key,Body:bytes,ContentType:file.type,ServerSideEncryption:process.env.S3_SSE || undefined,Metadata:{sha256}}));
    return {storageKey:key,originalName:file.name,mimeType:file.type,size:file.size,sha256};
  }
  const root=path.resolve(process.env.UPLOAD_DIR||'./storage/uploads');
  const full=path.join(root,key);
  await fs.mkdir(path.dirname(full),{recursive:true});
  await fs.writeFile(full,bytes,{flag:'wx'});
  return {storageKey:key,originalName:file.name,mimeType:file.type,size:file.size,sha256};
}

export async function signedEvidenceUrl(storageKey:string){
  const client=s3();
  if(client) return getSignedUrl(client,new GetObjectCommand({Bucket:process.env.S3_BUCKET!,Key:storageKey}),{expiresIn:300});
  return null;
}
